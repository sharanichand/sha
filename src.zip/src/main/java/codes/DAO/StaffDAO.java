package codes.DAO;

import java.util.List;

import codes.Model.Staff;

public interface StaffDAO {
	void addStaff(Staff s);
	void delStaff(int sid);
	void updStaff(Staff s);
	Staff viewStaffById(int sid);
	List<Staff> viewAllStaffs();
}
