package codes.DAO;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import codes.Model.Staff;

@Repository
public class StaffDAOImpl implements StaffDAO {

	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;
	
	@Override
	public void addStaff(Staff s) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s);
		t.commit();
	}

	@Override
	public void delStaff(int sid) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		Staff x = (Staff)ss.load(Staff.class,sid);
		ss.delete(x);
		t.commit();
	}

	@Override
	public void updStaff(Staff s) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		Staff x = (Staff)ss.load(Staff.class,s.getSid());
		x.setSname(s.getSname());
		x.setDept(s.getDept());
		ss.saveOrUpdate(x);
		t.commit();
	}

	@Override
	public Staff viewStaffById(int sid) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		Staff x = (Staff)ss.load(Staff.class,sid);
		t.commit();
		return x;
	}

	@Override
	public List<Staff> viewAllStaffs() {
		ss = sf.openSession();
		t = ss.beginTransaction();
		List<Staff> l = ss.createCriteria(Staff.class).list();
		t.commit();
		return l;
	}

}
