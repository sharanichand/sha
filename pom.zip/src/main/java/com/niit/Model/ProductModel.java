package com.niit.Model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
@Entity
public class ProductModel {


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pid;
	@Column
	private String pname;
	@Column
	private String pprice;
	@Column
	private String pquan ;
	@Column
	private String pdescr;
@Transient
private MultipartFile file;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public String getPprice() {
	return pprice;
}
public void setPprice(String pprice) {
	this.pprice = pprice;
}
public String getPquan() {
	return pquan;
}
public void setPquan(String pquan) {
	this.pquan = pquan;
}
public String getPdescr() {
	return pdescr;
}
public void setPdescr(String pdescr) {
	this.pdescr = pdescr;
}
public MultipartFile getFile() {
	return file;
}
public void setFile(MultipartFile file) {
	this.file = file;
} 
}
