package com.niit.DAO;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.Model.RegModel;
@Repository
public class RegDAOImpl implements RegDAO {
	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;

	@Override
	public void addRegModel(RegModel s) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s);
		t.commit();
	}

	@Override
	public void delRegModel(String email) {
		// TODO Auto-generated method stub

	}

}
