package com.niit.DAO;
import com.niit.Model.RegModel;
public interface RegDAO {
	void addRegModel(RegModel s);
/*	RegModel viewRegModelById(String email);*/
	void delRegModel(String email);
}

