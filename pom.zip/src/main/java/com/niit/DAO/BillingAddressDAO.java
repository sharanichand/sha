package com.niit.DAO;
import java.util.List;

import com.niit.Model.Address;
public interface BillingAddressDAO {
	void addAddress(Address s2);
	void delAddress(int aid);
	void updAddress(Address s2);
	Address viewAddModelById(int aid);
	List<Address> viewAllAddress();


}
