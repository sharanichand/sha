/**
 * 
 */
package com.niit.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.Model.ProductModel;

/**
 * @author User
 *
 */
@Repository
public class ProDAOImpl implements ProDAO {

	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;
	
	@Override
	public void addProductModel(ProductModel s1) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s1);
		t.commit();
	}

	@Override
	public void delProductModel(int pid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updProductModel(ProductModel s1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ProductModel viewProductModelById(int pid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductModel> viewAllProductModels() {
		// TODO Auto-generated method stub
		return null;
	}

}
