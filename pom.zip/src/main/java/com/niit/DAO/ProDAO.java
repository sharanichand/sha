package com.niit.DAO;
import java.util.List;
import com.niit.Model.ProductModel;
public interface ProDAO {
void addProductModel(ProductModel s1);
void delProductModel(int pid);
void updProductModel(ProductModel s1);
ProductModel viewProductModelById(int pid);
List<ProductModel> viewAllProductModels();

}
