package com.niit.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.DAO.*;
import com.niit.Model.*;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;

@Controller
public class FirstController {
	@Autowired
	RegDAO sd;
	@Autowired
	ProDAO pd;
	@Autowired 
	AddressDAO ad;
	@Autowired
	BillingAddressDAO ba;
	ModelAndView m;
	
	/*@RequestMapping("/")
	 * 
	public String gouserprofile() {
	System.out.println("index");
	return "index";
	}*/
	
	
	@ModelAttribute("staffobj")
	public RegModel getRegModel(){
		return new RegModel();
	}
	@ModelAttribute("productobj")
	public ProductModel getProductModel(){
		return new ProductModel();
	}
	@RequestMapping("/")
	public String goregistration() {
	System.out.println("Home");
	return "Home";
	}
	@RequestMapping("/login")
	public String gouserprofile2() {
		System.out.println("login");
		return "login";
	}
	@RequestMapping("/Home")
	public String gouserprofile3() {
		System.out.println("Home");
		return "Home";
	}
	@RequestMapping("/AddProduct")
	public String gouserprofile5() {
		System.out.println("AddProduct");
		return "AddProduct";
	}
	@RequestMapping("/register")
	public String gouserprofile4() {
		System.out.println("register");
		return "register";
	}
	
	
	@RequestMapping("/save")
	public ModelAndView addC(@Valid @ModelAttribute("staffobj")RegModel x,BindingResult br) 
	{
		if(br.hasErrors()){
			m= new ModelAndView("register");
			
			m.addObject("staffobj", x);
			return m;
		}
			
		m = new ModelAndView("login");
		String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
        if(x.getEmail().matches(emailregex)&&x.getPass().equals(x.getRepass()))
        sd.addRegModel(x);
        else{
			m= new ModelAndView("register");
		    m.addObject("staffobj", x);
			return m;
        }
        return m;
	}

	@RequestMapping("/add")
	public String goAdd(@ModelAttribute("productobj")ProductModel x, HttpServletRequest req){
		System.out.print("In add product");
		pd.addProductModel(x);
		MultipartFile itemImage = x.getFile();
        String rootDirectory =req.getSession().getServletContext().getRealPath("/");
        File f = new File(rootDirectory + "resources\\images\\");
        if(!f.exists())
        f.mkdirs();
        Path path = Paths.get(rootDirectory +"resources\\images\\"+x.getPid()+".jpg");

        if (itemImage != null && !itemImage.isEmpty()) {
            try {
            itemImage.transferTo(new File(path.toString()));
            System.out.println("Image Uploaded - "+rootDirectory +"resources\\images\\"+x.getPid()+".jpg");
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException("item image saving failed.", e);
            }
        }
		return "AddProduct";
	}
	@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", pd.viewAllProductModels());
		return m;
	}
    
    @RequestMapping("/viewallproducts")
	public ModelAndView goviewproducts() {
	System.out.println("ViewAllProduct");
   ModelAndView view=new ModelAndView("ViewAllProducts");
	view.addObject("data", ad.viewAllAddress());	
	return view;
	}
	@RequestMapping("/viewad/{id}")
	public ModelAndView goviewproduct(@PathVariable("id")int id) {
	System.out.println(id);
	ModelAndView view=new ModelAndView("viewproducts");
	view.addObject("data", ad.viewAddModelById(id));	
	return view;
	}
	/*
	@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", sd.viewAllRegModels());
		return m;
	}*/
} 